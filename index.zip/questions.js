// Cloud Operations 2 - Practice Questions Database
// 110 questions total (10 per week for 11 weeks)

const questionsDB = {
    week1: {
        title: "Week 1: DevOps 2 - Part 1",
        subtitle: "CI/CD, Automated Testing, and Code Reviews",
        questions: [
            {
                id: 1,
                scenario: "Your development team is implementing a CI/CD pipeline for a microservices-based application. The team has noticed that while unit tests pass successfully in the development environment, integration issues frequently occur in production. The current pipeline uses AWS CodePipeline with CodeBuild for running unit tests, but there's no automated integration testing stage. The application consists of five microservices that communicate via REST APIs, and deployment failures have increased by 40% over the past month. Management wants to reduce deployment failures while maintaining rapid release cycles.",
                question: "Which combination of actions would BEST address this situation? (Select TWO)",
                options: [
                    "Increase the frequency of unit test execution and add more unit test cases to achieve 100% code coverage across all microservices",
                    "Add an integration testing stage in CodePipeline that deploys services to a staging environment and runs API contract tests before production deployment",
                    "Implement Amazon CodeGuru Reviewer to automatically review code changes and block deployments if critical issues are detected",
                    "Configure CodeBuild to run integration tests in parallel with unit tests to reduce overall pipeline execution time",
                    "Create a separate staging environment that mirrors production and add a manual approval stage after integration testing"
                ],
                correct: ["B", "E"],
                multipleAnswers: true,
                explanation: "Integration testing in a staging environment (B) catches issues that unit tests miss, and a manual approval stage (E) provides oversight before production. Simply adding more unit tests (A) won't catch integration issues, CodeGuru (C) focuses on code quality not integration, and parallel testing (D) doesn't add integration coverage."
            },
            {
                id: 2,
                scenario: "A financial services company is building a CI/CD pipeline for their payment processing application. Due to regulatory requirements, all code changes must be reviewed for security vulnerabilities and compliance issues before deployment. The development team currently uses AWS CodeCommit for source control and wants to automate security scanning without significantly impacting developer productivity. The team deploys approximately 50 code changes per day, and manual security reviews are creating a bottleneck. They need a solution that provides actionable feedback within minutes of code commit.",
                question: "What is the MOST efficient approach to meet these requirements?",
                options: [
                    "Configure AWS CodePipeline to trigger AWS Lambda functions that perform custom security scans using third-party tools, then store results in Amazon S3 for manual review",
                    "Implement Amazon CodeGuru Security to automatically scan code on every commit, integrate findings into pull requests, and configure CodePipeline to fail builds when critical vulnerabilities are detected",
                    "Set up AWS CodeBuild to run OWASP dependency checks and static analysis tools, then require manual approval from the security team before proceeding to deployment stages",
                    "Use AWS Security Hub to aggregate security findings from multiple sources and create Amazon EventBridge rules to notify developers via Amazon SNS when issues are detected"
                ],
                correct: ["B"],
                multipleAnswers: false,
                explanation: "CodeGuru Security (B) provides automated, fast security scanning with immediate feedback in pull requests and can block deployments automatically. Option A requires manual review defeating the automation goal, C still has manual bottleneck, and D is for aggregating findings not scanning code."
            },
            {
                id: 3,
                scenario: "Your organization has adopted a DevOps culture and implemented CI/CD pipelines across 15 different application teams. Each team uses AWS CodePipeline with CodeBuild for automated testing. However, the operations team has noticed inconsistent testing practices: some teams only run unit tests, others skip tests entirely during hotfixes, and test coverage varies from 30% to 85% across projects. Leadership wants to establish minimum quality gates while allowing teams flexibility in their testing strategies. The goal is to prevent deployments of code that doesn't meet basic quality standards without creating excessive overhead.",
                question: "Which approach would BEST balance quality requirements with team autonomy?",
                options: [
                    "Mandate that all teams achieve exactly 80% code coverage and configure CodeBuild to fail builds that don't meet this threshold, with no exceptions for any deployment type",
                    "Create organizational standards requiring minimum 60% code coverage for unit tests and at least one integration test suite, implement these checks in CodeBuild, and provide teams with reusable buildspec templates",
                    "Implement Amazon CodeGuru Reviewer across all repositories with automatic blocking of pull requests that have critical issues, and require security team approval for all production deployments",
                    "Establish a centralized testing team that reviews all code changes before deployment and maintains a shared test suite that all applications must pass"
                ],
                correct: ["B"],
                multipleAnswers: false,
                explanation: "Option B provides reasonable minimum standards (60% coverage, integration tests) while giving teams flexibility and providing reusable templates to help them succeed. A is too rigid with no flexibility, C focuses on code review not testing standards, and D creates a bottleneck and removes team autonomy."
            },
            {
                id: 4,
                scenario: "A SaaS company runs a multi-tenant application that processes customer data through a series of AWS Lambda functions triggered by API Gateway. The development team uses AWS CodePipeline for continuous delivery, with stages for source (CodeCommit), build (CodeBuild), and deploy (CloudFormation). Recently, a deployment introduced a bug that caused data processing failures for 20% of customers, but the issue wasn't detected until customers reported problems. The team wants to implement automated testing that validates the entire workflow before production deployment, including API endpoints, Lambda function execution, and data processing accuracy.",
                question: "What testing strategy should be implemented in the CodePipeline to catch such issues?",
                options: [
                    "Add a CodeBuild stage that runs unit tests for each Lambda function individually, checking function logic and mocking all external dependencies and API calls",
                    "Implement a testing stage that deploys the application to a staging environment, runs end-to-end integration tests simulating real customer workflows, and validates data processing results before promoting to production",
                    "Configure AWS X-Ray tracing in production and use Amazon CloudWatch alarms to automatically roll back deployments when error rates exceed thresholds",
                    "Use AWS CodeDeploy with canary deployment strategy to gradually roll out changes to 10% of customers first, monitoring for errors before full deployment"
                ],
                correct: ["B"],
                multipleAnswers: false,
                explanation: "End-to-end integration testing in staging (B) validates the complete workflow including API, Lambda, and data processing before production. Unit tests alone (A) won't catch integration issues, X-Ray (C) only detects issues after deployment to production, and canary deployment (D) still exposes some customers to bugs."
            },
            {
                id: 5,
                scenario: "Your team maintains a legacy monolithic application that is being gradually refactored into microservices. The CI/CD pipeline uses AWS CodePipeline with multiple stages: source control (CodeCommit), build (CodeBuild), unit testing (CodeBuild), and deployment (CodeDeploy). The unit testing stage currently takes 45 minutes to complete because it runs tests sequentially for all modules. The team deploys 3-4 times per day, and the long testing duration is impacting productivity. The application has 12 major modules with independent test suites, and test failures in one module shouldn't block testing of other modules.",
                question: "How can you optimize the testing stage to reduce pipeline execution time while maintaining test reliability?",
                options: [
                    "Configure CodeBuild to use a larger compute instance type with more CPU and memory resources to speed up sequential test execution",
                    "Modify the buildspec.yml to run tests for all 12 modules in parallel using CodeBuild batch builds, with each module tested in a separate build job",
                    "Reduce the number of test cases by removing redundant tests and focusing only on critical path testing to decrease overall execution time",
                    "Implement test result caching in CodeBuild so that unchanged modules skip testing, only running tests for modules with code changes"
                ],
                correct: ["B"],
                multipleAnswers: false,
                explanation: "Parallel testing with batch builds (B) can dramatically reduce execution time from 45 minutes to the duration of the longest module test. Larger instances (A) provide marginal improvement, removing tests (C) reduces reliability, and caching (D) helps but doesn't address the fundamental sequential execution problem."
            }
        ]
    }
};

{
    id: 6,
        scenario: "A healthcare technology company is developing a patient management system that must comply with HIPAA regulations. The development team uses AWS CodeCommit for version control and wants to implement automated code reviews to identify potential security vulnerabilities, particularly around data handling and encryption. The team consists of 8 developers who create approximately 30 pull requests per week. Manual code reviews by the security team are thorough but take 2-3 days, creating delays. The company needs a solution that provides immediate security feedback while still maintaining human oversight for critical changes.",
            question: "Which implementation would BEST meet these requirements?",
                options: [
                    "Configure Amazon CodeGuru Reviewer to automatically analyze pull requests for security issues and code quality, provide inline recommendations, and require security team approval only for pull requests with high-severity findings",
                    "Implement AWS Lambda functions triggered by CodeCommit events to run custom security scanning tools, block all pull requests by default, and require security team review before any merge",
                    "Use AWS CodeBuild to run static application security testing (SAST) tools on every commit, generate reports in Amazon S3, and send notifications to the security team via Amazon SNS",
                    "Deploy third-party code review tools on Amazon EC2 instances, integrate with CodeCommit webhooks, and maintain a queue of pull requests for security team review"
                ],
                    correct: ["A"],
                        multipleAnswers: false,
                            explanation: "CodeGuru Reviewer (A) provides immediate automated security feedback while allowing human oversight for high-severity issues, balancing speed and security. Option B blocks everything creating delays, C requires manual review of all reports, and D doesn't provide automation benefits."
},
{
    id: 7,
        scenario: "Your organization has implemented a CI/CD pipeline using AWS CodePipeline for a Node.js application. The pipeline includes stages for source (CodeCommit), build (CodeBuild), test (CodeBuild), and deploy (Elastic Beanstalk). The testing stage runs unit tests using Jest and generates code coverage reports. Management has mandated that all deployments must have at least 75% code coverage. Currently, the pipeline deploys even when coverage is below this threshold because the test stage only checks if tests pass, not coverage percentage. You need to enforce the coverage requirement without modifying the application code.",
            question: "What is the MOST effective way to implement this requirement?",
                options: [
                    "Modify the buildspec.yml in the test stage to parse the coverage report, use conditional logic to fail the build if coverage is below 75%, and configure CodePipeline to stop on build failure",
                    "Create an AWS Lambda function that retrieves coverage reports from S3, calculates the percentage, and uses AWS Step Functions to control whether the pipeline continues to the deploy stage",
                    "Configure Amazon CloudWatch Events to monitor CodeBuild completion, trigger a Lambda function to check coverage, and manually stop the pipeline if coverage is insufficient",
                    "Implement a manual approval stage after testing where reviewers check the coverage report before approving deployment to production"
                ],
                    correct: ["A"],
                        multipleAnswers: false,
                            explanation: "Modifying buildspec.yml (A) is the most direct and efficient approach, failing the build immediately if coverage is insufficient. Options B and C add unnecessary complexity with Lambda and Step Functions, while D reintroduces manual processes that slow down deployment."
},
{
    id: 8,
        scenario: "A software development company uses AWS CodePipeline to automate deployments of their e-commerce platform. The pipeline has been experiencing intermittent failures in the testing stage, where integration tests sometimes fail due to timing issues when external services (payment gateway, inventory system) are slow to respond. The tests are configured with a 5-second timeout, which works 90% of the time but occasionally causes false failures. The team wants to improve test reliability without masking real issues or significantly increasing pipeline execution time. The external services are third-party APIs that the team cannot modify.",
            question: "What approach would BEST improve test reliability?",
                options: [
                    "Increase the timeout to 30 seconds for all integration tests to accommodate slow external service responses",
                    "Implement retry logic in the test code with exponential backoff for external service calls, and configure tests to fail only after 3 consecutive failures",
                    "Remove integration tests that depend on external services from the pipeline and run them separately on a scheduled basis",
                    "Mock all external service calls in the integration tests to eliminate dependency on third-party API response times"
                ],
                    correct: ["B"],
                        multipleAnswers: false,
                            explanation: "Retry logic with exponential backoff (B) handles transient failures while still catching real issues, and failing after 3 attempts ensures genuine problems are detected. Option A might mask real performance issues, C reduces test coverage in the pipeline, and D defeats the purpose of integration testing."
},
{
    id: 9,
        scenario: "Your team is building a CI/CD pipeline for a Python-based data processing application that runs on AWS Lambda. The application processes files uploaded to Amazon S3, transforms the data, and stores results in Amazon DynamoDB. The current pipeline uses CodePipeline with CodeBuild for testing, but tests only validate individual Lambda function logic. Recently, a deployment caused production issues because the Lambda function's IAM role lacked permissions to write to DynamoDB, even though the function code was correct. The team wants to catch such configuration issues before production deployment.",
            question: "Which testing approach would BEST prevent this type of issue?",
                options: [
                    "Enhance unit tests to mock AWS service calls and verify that the correct API methods are invoked with proper parameters",
                    "Add an integration testing stage that deploys the Lambda function to a test environment using AWS SAM or CloudFormation, uploads a test file to S3, and verifies end-to-end functionality including DynamoDB writes",
                    "Implement AWS Config rules to check Lambda function IAM policies and trigger Amazon SNS notifications when permissions are insufficient",
                    "Use AWS IAM Access Analyzer to review Lambda function permissions before deployment and require manual approval if issues are detected"
                ],
                    correct: ["B"],
                        multipleAnswers: false,
                            explanation: "Integration testing with actual deployment (B) validates the complete configuration including IAM permissions, catching issues before production. Unit tests with mocks (A) won't catch permission issues, Config rules (C) detect but don't prevent deployment, and IAM Access Analyzer (D) adds manual steps and delays."
},
{
    id: 10,
        scenario: "A development team is implementing continuous integration for a microservices architecture consisting of 8 services deployed on Amazon ECS. Each service has its own CodePipeline, and services communicate via REST APIs. The team has noticed that when one service is updated, dependent services sometimes break due to API contract changes. For example, a recent update to the authentication service changed the response format, breaking three downstream services. The team wants to prevent such breaking changes from reaching production while maintaining independent deployment pipelines for each service.",
            question: "What strategy would MOST effectively address this challenge?",
                options: [
                    "Implement API versioning for all services and maintain backward compatibility for at least two versions, allowing dependent services time to migrate",
                    "Create a centralized integration testing pipeline that deploys all services together and runs cross-service tests before any individual service can deploy to production",
                    "Use Amazon CodeGuru Reviewer to analyze API changes and automatically notify owners of dependent services when breaking changes are detected",
                    "Implement contract testing using tools like Pact, where each service pipeline validates that API contracts are maintained before deployment"
                ],
                    correct: ["D"],
                        multipleAnswers: false,
                            explanation: "Contract testing (D) validates API contracts in each service's pipeline independently, catching breaking changes before deployment while maintaining pipeline independence. API versioning (A) helps but doesn't prevent breaks, centralized testing (B) defeats independent deployments, and CodeGuru (C) doesn't validate contracts."
}
        ]
    },

week2: {
    title: "Week 2: DevOps 2 - Part 2",
        subtitle: "CI/CD Pipeline Integration, Deployment Strategies, and DevOps Environments",
            questions: [
                {
                    id: 11,
                    scenario: "Your company runs a customer-facing web application on Amazon EC2 instances behind an Application Load Balancer. The application serves 50,000 active users daily, and any downtime directly impacts revenue. The development team wants to implement automated deployments using AWS CodeDeploy, but the operations team is concerned about the risk of deploying faulty code that could cause widespread outages. The current manual deployment process takes 2 hours and requires taking the application offline for 15 minutes. Management wants zero-downtime deployments with the ability to quickly rollback if issues are detected.",
                    question: "Which deployment strategy would BEST meet these requirements?",
                    options: [
                        "Implement an in-place deployment strategy using CodeDeploy, deploying to all instances simultaneously to minimize deployment duration",
                        "Configure a blue/green deployment with CodeDeploy, deploying to a new set of instances, testing thoroughly, then switching traffic via the load balancer with the ability to quickly switch back if needed",
                        "Use a rolling deployment strategy that updates 25% of instances at a time, with health checks between batches to detect issues early",
                        "Implement a canary deployment that routes 5% of traffic to the new version for 1 hour, monitors metrics, then gradually increases traffic if no issues are detected"
                    ],
                    correct: ["B"],
                    multipleAnswers: false,
                    explanation: "Blue/green deployment (B) provides zero-downtime deployment and instant rollback capability by maintaining both environments and switching traffic at the load balancer. In-place (A) risks all instances, rolling (C) provides gradual rollout but slower rollback, and canary (D) is good but blue/green offers faster complete rollback."
                },
                {
                    id: 12,
                    scenario: "A financial services company has a critical trading application deployed on AWS using CodePipeline for continuous delivery. The pipeline includes stages for source (CodeCommit), build (CodeBuild), integration testing (CodeBuild), and deployment (CodeDeploy to EC2). During peak trading hours (9 AM - 4 PM EST), the application handles thousands of transactions per second, and any deployment during this time could risk transaction failures. However, the development team needs to deploy bug fixes and features multiple times per day. The current pipeline deploys immediately after tests pass, which has caused issues during trading hours.",
                    question: "How should the pipeline be modified to safely enable frequent deployments?",
                    options: [
                        "Configure the pipeline to automatically pause before the deployment stage and require manual approval from operations team during trading hours",
                        "Implement Amazon EventBridge scheduled rules to automatically approve deployments only during off-peak hours (4 PM - 9 AM EST), with emergency override capability",
                        "Use AWS CodeDeploy with a canary deployment strategy that routes only 1% of traffic to new versions during trading hours, increasing to 100% after hours",
                        "Modify the pipeline to queue deployments during trading hours and automatically execute them in batch after 4 PM using AWS Step Functions"
                    ],
                    correct: ["D"],
                    multipleAnswers: false,
                    explanation: "Queuing deployments with Step Functions (D) allows the team to continue their workflow while safely deferring actual deployment to off-peak hours, with automation reducing manual overhead. Manual approval (A) creates bottlenecks, EventBridge rules (B) lack flexibility, and canary during peak (C) still risks production during critical hours."
                },
                {
                    id: 13,
                    scenario: "Your organization is migrating from manual deployments to automated CI/CD using AWS CodePipeline and CodeDeploy. The application runs on 20 Amazon EC2 instances behind an Application Load Balancer. During a recent test deployment using an in-place strategy, the deployment failed halfway through, leaving 10 instances with the new version and 10 with the old version. This caused inconsistent behavior and data corruption issues. The team needs a deployment strategy that ensures all instances are running the same version and can handle deployment failures gracefully without leaving the application in an inconsistent state.",
                    question: "Which deployment configuration would BEST address these requirements?",
                    options: [
                        "Configure CodeDeploy with an in-place deployment using the 'AllAtOnce' deployment configuration to ensure all instances are updated simultaneously",
                        "Implement a blue/green deployment strategy where a completely new set of instances is created, validated, and then traffic is switched atomically via the load balancer",
                        "Use a rolling deployment with the 'OneAtATime' configuration and enable automatic rollback on deployment failure",
                        "Configure an immutable deployment strategy using AWS Elastic Beanstalk that creates new instances, validates them, and then terminates old instances"
                    ],
                    correct: ["B"],
                    multipleAnswers: false,
                    explanation: "Blue/green deployment (B) ensures atomic cutover - all traffic switches at once, preventing mixed versions. If deployment fails, old environment remains untouched. AllAtOnce (A) risks all instances simultaneously, rolling (C) can still have mixed versions during deployment, and Elastic Beanstalk (D) requires migration from current setup."
                }
            ]
}
    },

week3: {
    title: "Week 3: DevOps 2 - Part 3",
        subtitle: "DevSecOps and Security Integration",
            questions: [
                {
                    id: 21,
                    scenario: "A healthcare application development team is implementing DevSecOps practices for their HIPAA-compliant patient portal. The application handles sensitive patient data and must undergo security scanning before each deployment. Currently, security scans are performed manually by the security team after development is complete, taking 3-5 days and creating a bottleneck. The team deploys weekly, and management wants to shift security left in the development process while maintaining compliance standards. The application uses AWS CodePipeline with stages for source, build, test, and deploy.",
                    question: "Which approach would BEST integrate security scanning into the CI/CD pipeline while maintaining compliance?",
                    options: [
                        "Add Amazon CodeGuru Security scanning in the build stage to detect vulnerabilities in code, and Amazon Inspector scanning in a pre-deployment stage to check runtime vulnerabilities, with automatic pipeline failure on critical findings",
                        "Implement AWS Security Hub to aggregate findings from multiple security tools, then require manual security team approval before each production deployment",
                        "Configure AWS CodeBuild to run OWASP ZAP penetration testing after deployment to staging, generating reports for security team review before production",
                        "Use AWS Lambda functions to trigger third-party SAST tools on code commit, storing results in S3, and sending SNS notifications to security team for review"
                    ],
                    correct: ["A"],
                    multipleAnswers: false,
                    explanation: "Option A provides automated security scanning at multiple stages (code-level with CodeGuru, runtime with Inspector) with automatic blocking of critical issues, shifting security left while maintaining standards. B still requires manual approval creating delays, C only scans after deployment, and D requires manual review defeating automation goals."
                },
                {
                    id: 22,
                    scenario: "Your company is developing a microservices-based e-commerce platform on AWS. Recent security audits revealed that several services have vulnerabilities in their dependencies, including outdated libraries with known CVEs. The development team uses various programming languages (Python, Node.js, Java) across different services. Management wants to implement automated vulnerability scanning for all dependencies across the entire application portfolio without disrupting the current development workflow. The team uses AWS CodeCommit for source control and CodePipeline for CI/CD.",
                    question: "What is the MOST comprehensive approach to address dependency vulnerabilities?",
                    options: [
                        "Implement Amazon Inspector to scan EC2 instances and Lambda functions for vulnerabilities, with automatic notifications when issues are detected",
                        "Configure AWS CodeBuild to run language-specific dependency scanning tools (pip-audit for Python, npm audit for Node.js, OWASP Dependency-Check for Java) in the build stage, failing builds when high-severity vulnerabilities are found",
                        "Use Amazon CodeGuru Security to scan source code for security issues and integrate findings into pull requests for developer review",
                        "Deploy AWS Security Hub with automated remediation workflows using AWS Systems Manager to patch vulnerable dependencies automatically"
                    ],
                    correct: ["B"],
                    multipleAnswers: false,
                    explanation: "Option B provides comprehensive dependency scanning across all languages in the build stage, catching issues before deployment. Inspector (A) scans runtime environments not dependencies, CodeGuru Security (C) focuses on code not dependencies, and Security Hub (D) aggregates findings but doesn't scan dependencies directly."
                },
                {
                    id: 23,
                    scenario: "A financial technology startup is building a payment processing API that must comply with PCI DSS requirements. The security team has identified that secrets (API keys, database passwords, encryption keys) are currently hardcoded in application configuration files stored in AWS CodeCommit. This violates security best practices and compliance requirements. The development team needs a solution that securely manages secrets, integrates with their existing CI/CD pipeline (CodePipeline and CodeDeploy), and allows for secret rotation without code changes or redeployment.",
                    question: "Which solution would BEST address the secret management requirements?",
                    options: [
                        "Store secrets in AWS Systems Manager Parameter Store with SecureString type, reference them in application code using AWS SDK, and configure IAM roles for EC2 instances to access parameters",
                        "Use AWS Secrets Manager to store all secrets with automatic rotation enabled, configure applications to retrieve secrets at runtime using AWS SDK, and use IAM roles to control access",
                        "Encrypt secrets using AWS KMS and store encrypted values in CodeCommit, then decrypt them during the build process in CodeBuild using KMS keys",
                        "Store secrets in Amazon S3 with server-side encryption, configure bucket policies to restrict access, and download secrets during application startup"
                    ],
                    correct: ["B"],
                    multipleAnswers: false,
                    explanation: "AWS Secrets Manager (B) provides automatic rotation, versioning, and fine-grained access control, meeting all requirements including rotation without redeployment. Parameter Store (A) lacks automatic rotation, storing encrypted in CodeCommit (C) still exposes secrets in version control, and S3 (D) doesn't provide rotation capabilities."
                }
            ]
},

week4: {
    title: "Week 4: Infrastructure as Code - Part 1",
        subtitle: "IaC Fundamentals, CloudFormation, and DevOps Integration",
            questions: [
                {
                    id: 31,
                    scenario: "Your organization is standardizing on Infrastructure as Code using AWS CloudFormation. A development team has created a CloudFormation template that deploys a web application with an Application Load Balancer, Auto Scaling group, and RDS database. The template works in the development environment, but when deployed to production, it fails because the production VPC has different subnet IDs and security group configurations. The team wants to use the same template across all environments (dev, staging, production) without maintaining multiple copies.",
                    question: "What is the BEST approach to make the template reusable across environments?",
                    options: [
                        "Create separate CloudFormation templates for each environment with hardcoded values specific to that environment",
                        "Use CloudFormation parameters for environment-specific values (VPC ID, subnet IDs, security groups) and pass different parameter files for each environment deployment",
                        "Use AWS Systems Manager Parameter Store to store environment-specific values and reference them in the template using dynamic references",
                        "Implement CloudFormation conditions to check the AWS account ID and use different resource configurations based on the account"
                    ],
                    correct: ["B"],
                    multipleAnswers: false,
                    explanation: "CloudFormation parameters (B) provide the cleanest approach for environment-specific values, allowing one template with different parameter files per environment. Separate templates (A) create maintenance overhead, Parameter Store (C) adds complexity, and account-based conditions (D) are inflexible and harder to maintain."
                },
                {
                    id: 32,
                    scenario: "A DevOps team is using AWS CloudFormation to manage infrastructure for a microservices application. The template has grown to over 2000 lines and includes resources for networking (VPC, subnets, route tables), compute (EC2, Auto Scaling), databases (RDS, DynamoDB), and monitoring (CloudWatch alarms, dashboards). The template is becoming difficult to maintain, and different teams need to update different sections independently. For example, the networking team wants to modify VPC configuration without affecting database resources managed by the database team.",
                    question: "How should the team restructure their CloudFormation implementation?",
                    options: [
                        "Split the monolithic template into multiple nested stacks organized by resource type (networking stack, compute stack, database stack), with a parent stack that orchestrates them",
                        "Use CloudFormation modules to create reusable components for common patterns, then reference these modules in the main template",
                        "Implement CloudFormation StackSets to deploy the same template across multiple accounts and regions",
                        "Convert the CloudFormation template to AWS CDK code, which provides better organization through programming language constructs"
                    ],
                    correct: ["A"],
                    multipleAnswers: false,
                    explanation: "Nested stacks (A) allow logical separation by resource type with independent updates while maintaining relationships through outputs/parameters. Modules (B) are for reusable patterns not organization, StackSets (C) are for multi-account deployment not organization, and CDK (D) is a different tool requiring migration."
                }
            ]
},

week5: {
    title: "Week 5: Infrastructure as Code - Part 2",
        subtitle: "Advanced CloudFormation, AWS CDK, and Testing",
            questions: [
                {
                    id: 41,
                    scenario: "Your team is using AWS CloudFormation to manage infrastructure across 50 different application stacks. Recently, several stacks have experienced drift - manual changes made through the AWS Console that aren't reflected in the CloudFormation templates. This has caused issues when updating stacks, as CloudFormation tries to revert manual changes. The operations team needs to detect drift regularly and ensure that infrastructure matches the defined templates. Management wants an automated solution that alerts the team when drift is detected and provides detailed information about what changed.",
                    question: "What is the MOST effective approach to manage and monitor CloudFormation drift?",
                    options: [
                        "Create an AWS Lambda function triggered by Amazon EventBridge on a schedule that runs drift detection on all stacks, publishes results to SNS, and stores detailed drift reports in S3",
                        "Enable AWS Config rules to monitor CloudFormation stacks and trigger notifications when resources are modified outside of CloudFormation",
                        "Implement AWS CloudTrail logging and create CloudWatch alarms that trigger when API calls modify resources managed by CloudFormation",
                        "Use AWS Systems Manager Change Calendar to block all manual changes during business hours and only allow changes through CloudFormation"
                    ],
                    correct: ["A"],
                    multipleAnswers: false,
                    explanation: "Lambda with scheduled drift detection (A) provides comprehensive automated drift monitoring with detailed reports. Config rules (B) monitor resource changes but don't provide CloudFormation-specific drift analysis, CloudTrail (C) logs changes but doesn't detect drift, and Change Calendar (D) is preventive not detective."
                }
            ]
},

week6: {
    title: "Week 6: Logging and Scaling - Part 1",
        subtitle: "Auto Scaling and Elastic Load Balancing",
            questions: [
                {
                    id: 51,
                    scenario: "An e-commerce company runs their web application on Amazon EC2 instances in an Auto Scaling group behind an Application Load Balancer. The application experiences predictable traffic patterns: low traffic from midnight to 6 AM (100 requests/min), moderate traffic from 6 AM to 6 PM (500 requests/min), and high traffic from 6 PM to midnight (2000 requests/min) during evening shopping hours. Currently, the Auto Scaling group uses target tracking scaling based on CPU utilization (70% target), but this results in slow scale-out during sudden traffic spikes at 6 PM, causing poor user experience for 10-15 minutes until new instances are ready.",
                    question: "How can the team optimize the Auto Scaling configuration to handle the predictable traffic pattern more effectively?",
                    options: [
                        "Implement predictive scaling that uses machine learning to forecast traffic and scale proactively based on historical patterns",
                        "Change the target tracking policy to use ALB request count per target metric instead of CPU utilization for faster response",
                        "Configure scheduled scaling actions to increase capacity before the 6 PM traffic spike and decrease after midnight",
                        "Reduce the target CPU utilization to 50% so that scaling occurs earlier and provides more buffer capacity"
                    ],
                    correct: ["A"],
                    multipleAnswers: false,
                    explanation: "Predictive scaling (A) is ideal for predictable patterns, scaling proactively before traffic increases. Scheduled scaling (C) works but is less flexible than ML-based prediction. Request count metric (B) is reactive not proactive, and lower CPU target (D) wastes resources during low-traffic periods."
                }
            ]
},

week7: {
    title: "Week 7: Logging and Scaling - Part 2",
        subtitle: "CloudWatch Monitoring and Logging",
            questions: [
                {
                    id: 61,
                    scenario: "A SaaS company operates a multi-tenant application where each customer has isolated resources. The operations team needs to monitor application performance, track custom business metrics (user logins, transactions processed, API calls per customer), and troubleshoot issues quickly. Currently, they only have basic EC2 metrics in CloudWatch, which don't provide enough visibility into application behavior. The team wants to implement comprehensive monitoring that includes custom metrics, log aggregation, and the ability to correlate metrics with logs for troubleshooting.",
                    question: "What combination of CloudWatch features would BEST meet these monitoring requirements? (Select TWO)",
                    options: [
                        "Install the CloudWatch agent on EC2 instances to collect custom application metrics and logs, publishing them to CloudWatch Metrics and CloudWatch Logs",
                        "Use CloudWatch Embedded Metric Format (EMF) to publish custom metrics directly from application code along with detailed log context",
                        "Configure AWS X-Ray to trace all application requests and automatically generate metrics from trace data",
                        "Implement CloudWatch Synthetics to create canaries that monitor application endpoints and generate availability metrics",
                        "Use CloudWatch Logs Insights to query and analyze logs, creating metric filters to extract custom metrics from log data"
                    ],
                    correct: ["A", "B"],
                    multipleAnswers: true,
                    explanation: "CloudWatch agent (A) provides comprehensive metric and log collection, while EMF (B) allows embedding metrics in logs for correlation. X-Ray (C) is for tracing not custom business metrics, Synthetics (D) is for external monitoring not internal metrics, and Logs Insights (E) is for analysis not collection."
                }
            ]
},

week8: {
    title: "Week 8: Monitoring and Troubleshooting - Part 1",
        subtitle: "CloudTrail, IAM, and Troubleshooting Methodology",
            questions: [
                {
                    id: 71,
                    scenario: "Your company's security team has detected unusual API activity in your AWS account. Several S3 buckets containing sensitive data were accessed by an unknown IAM role, and some objects were deleted. The security team needs to investigate: who made the changes, when they occurred, what actions were taken, and from which IP addresses. The company has AWS CloudTrail enabled with logs stored in S3, but manually searching through thousands of log files is time-consuming. The team needs to quickly analyze the trail logs to understand the security incident.",
                    question: "What is the MOST efficient approach to investigate this security incident using CloudTrail?",
                    options: [
                        "Download CloudTrail logs from S3 and use command-line tools like grep and jq to search for relevant events",
                        "Create a CloudTrail Lake event data store, import the relevant logs, and use SQL queries to analyze S3 API calls, filtering by event time, user identity, and source IP",
                        "Configure Amazon Athena to query CloudTrail logs directly in S3 using SQL, creating a table that maps to the log structure",
                        "Use AWS CloudTrail Event History in the console to search for S3 events, filtering by time range and event name"
                    ],
                    correct: ["B"],
                    multipleAnswers: false,
                    explanation: "CloudTrail Lake (B) provides the fastest and most powerful analysis with SQL queries, purpose-built for CloudTrail investigation. Athena (C) works but requires more setup, Event History (D) only shows 90 days and limited filtering, and manual log analysis (A) is time-consuming and error-prone."
                }
            ]
},

week9: {
    title: "Week 9: Monitoring and Troubleshooting - Part 2",
        subtitle: "Metrics, Container Insights, and Lambda Insights",
            questions: [
                {
                    id: 81,
                    scenario: "A company runs a containerized application on Amazon ECS with 20 services across multiple clusters. The operations team is experiencing intermittent performance issues but lacks visibility into container-level metrics like CPU, memory, network, and disk usage per container. They can see cluster-level metrics but need more granular data to identify which specific containers or tasks are causing problems. The team also wants to correlate container metrics with application logs for faster troubleshooting.",
                    question: "What should the team implement to gain comprehensive container-level monitoring?",
                    options: [
                        "Enable CloudWatch Container Insights for the ECS clusters, which automatically collects metrics at the cluster, service, and task level, and integrates with CloudWatch Logs",
                        "Install the CloudWatch agent as a sidecar container in each task definition to collect and publish custom metrics",
                        "Use AWS X-Ray to instrument the containerized applications and collect performance data",
                        "Configure ECS task definitions to publish logs to CloudWatch Logs and create metric filters to extract performance data"
                    ],
                    correct: ["A"],
                    multipleAnswers: false,
                    explanation: "Container Insights (A) is purpose-built for container monitoring, providing automatic collection of detailed metrics at all levels with log integration. Sidecar agents (B) add complexity and overhead, X-Ray (C) is for tracing not infrastructure metrics, and metric filters (D) don't provide comprehensive container metrics."
                }
            ]
},

week10: {
    title: "Week 10: Monitoring and Troubleshooting - Part 3",
        subtitle: "Log Analysis, VPC Flow Logs, and Application Monitoring",
            questions: [
                {
                    id: 91,
                    scenario: "A company's security team suspects that one of their EC2 instances may be compromised and communicating with external malicious IP addresses. They need to analyze network traffic patterns to identify suspicious connections. The VPC has VPC Flow Logs enabled and stored in CloudWatch Logs, but the team needs to efficiently query millions of log entries to find: connections to specific IP addresses, unusual port usage, rejected connection attempts, and traffic volume patterns over time.",
                    question: "What is the MOST effective way to analyze VPC Flow Logs for this security investigation?",
                    options: [
                        "Use CloudWatch Logs Insights to write queries that filter and aggregate flow log data, searching for specific IPs, ports, and connection patterns",
                        "Export flow logs to S3 and use Amazon Athena to query the data using SQL",
                        "Create CloudWatch metric filters to extract specific patterns from flow logs and visualize them in dashboards",
                        "Use AWS GuardDuty to automatically analyze flow logs and detect malicious activity"
                    ],
                    correct: ["A"],
                    multipleAnswers: false,
                    explanation: "CloudWatch Logs Insights (A) provides fast, interactive querying of flow logs with powerful filtering and aggregation capabilities, ideal for investigation. Athena (B) works but has more latency, metric filters (C) are for ongoing monitoring not investigation, and GuardDuty (D) is complementary but doesn't provide the detailed query capability needed."
                }
            ]
},

week11: {
    title: "Week 11: Monitoring and Troubleshooting - Part 4",
        subtitle: "Distributed Tracing with AWS X-Ray",
            questions: [
                {
                    id: 101,
                    scenario: "A microservices application consists of 8 services deployed on AWS Lambda and ECS, communicating via API Gateway and SQS queues. Users are reporting intermittent slow response times (5-10 seconds instead of the normal 1-2 seconds), but the issue is difficult to reproduce and doesn't affect all requests. The development team needs to identify which service in the chain is causing the latency and understand the complete request flow. Traditional logging shows individual service performance but doesn't provide end-to-end visibility across the distributed system.",
                    question: "What approach would BEST help identify the source of intermittent latency in this distributed system?",
                    options: [
                        "Implement AWS X-Ray tracing across all services to visualize the complete request path, identify slow segments, and analyze latency distributions with service maps and trace timelines",
                        "Enable detailed CloudWatch logging in all services and use CloudWatch Logs Insights to correlate logs by request ID",
                        "Configure CloudWatch Application Insights to automatically detect and analyze application issues",
                        "Use CloudWatch ServiceLens to combine X-Ray traces with CloudWatch metrics and logs for comprehensive observability"
                    ],
                    correct: ["D"],
                    multipleAnswers: false,
                    explanation: "CloudWatch ServiceLens (D) combines X-Ray tracing with metrics and logs, providing the most comprehensive view for troubleshooting distributed systems. X-Ray alone (A) provides tracing but ServiceLens adds metric correlation, log correlation (B) is manual and time-consuming, and Application Insights (C) is more for monolithic applications."
                }
            ]
}
    }
};

